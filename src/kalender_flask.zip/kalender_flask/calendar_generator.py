import calendar

class CalendarGenerator:
    def __init__(self, year):
        self.year = year
        self.cal = calendar.HTMLCalendar(calendar.SUNDAY)

    def generate_month_html(self, month):
        return self.cal.formatmonth(self.year, month)
