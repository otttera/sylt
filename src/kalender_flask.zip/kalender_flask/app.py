from flask import Flask, render_template
from calendar_generator import CalendarGenerator

app = Flask(__name__)

# Initialize the CalendarGenerator with a given year
year = 2025
generator = CalendarGenerator(year)

# Helper function to get previous and next months
def get_previous_next_months(month):
    prev_month = 12 if month == 1 else month - 1
    next_month = 1 if month == 12 else month + 1
    return prev_month, next_month

@app.route('/')
def index():
    # Home page with links to each month
    return render_template('index.html', year=year)

@app.route('/month/<int:month>')
def month_page(month):
    # Generate the HTML for the requested month
    calendar_html = generator.generate_month_html(month)
    prev_month, next_month = get_previous_next_months(month)
    
    # Render the month page
    return render_template('month.html', year=year, month=month, calendar_html=calendar_html, 
                           prev_month=prev_month, next_month=next_month)

if __name__ == '__main__':
    app.run(debug=True)
